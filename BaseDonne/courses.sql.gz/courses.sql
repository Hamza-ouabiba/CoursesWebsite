-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 31 déc. 2022 à 15:10
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `courses`
--

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `idCmd` int(11) NOT NULL,
  `dateEffe` date NOT NULL,
  `userid` int(11) NOT NULL,
  `etat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`idCmd`, `dateEffe`, `userid`, `etat`) VALUES
(57, '2022-12-31', 9, 1),
(58, '2022-12-31', 9, 1),
(59, '2022-12-31', 9, 1),
(60, '2022-12-31', 9, 1),
(61, '2022-12-31', 9, 1),
(62, '2022-12-31', 9, 1),
(63, '2022-12-31', 9, 1),
(64, '2022-12-31', 9, 1),
(65, '2022-12-31', 9, 1),
(66, '2022-12-31', 9, 1);

-- --------------------------------------------------------

--
-- Structure de la table `contient`
--

CREATE TABLE `contient` (
  `idCmd` int(11) NOT NULL,
  `idCourse` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `contient`
--

INSERT INTO `contient` (`idCmd`, `idCourse`) VALUES
(57, 140),
(58, 141),
(59, 150),
(59, 146),
(60, 145),
(61, 144),
(62, 156),
(63, 142),
(64, 158),
(65, 157),
(66, 155);

-- --------------------------------------------------------

--
-- Structure de la table `course`
--

CREATE TABLE `course` (
  `courseId` int(11) NOT NULL,
  `price` float NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `course`
--

INSERT INTO `course` (`courseId`, `price`, `image`, `title`, `category`) VALUES
(140, 5.9, './images/htmlBasics.PNG', 'basics of HTML', 'HTML'),
(141, 9.9, './images/htmlElements.png', 'HTML elements and tags', 'HTML'),
(142, 69.9, './images/cssSelectors.jpg', 'CSS selectors', 'CSS'),
(143, 19.9, './images/javascriptVariables.png', 'variables and data type of javascript', 'JS'),
(144, 29.9, './images/javascriptOperators.png', 'Javascript operators and conditions', 'JS'),
(145, 9.9, './images/javascriptDef.png', 'what is javascript?', 'JS'),
(146, 19.9, './images/htmlAttrVal.jpg', 'HTML attributes and values', 'HTML'),
(147, 29.9, './images/cssProperties.png', 'CSS properties', 'CSS'),
(148, 39.9, './images/javascriptObjects.png', 'Javascript objects and arrays', 'JS'),
(149, 29.9, './images/javascriptFunctions.png', 'The basics of javascript', 'JS'),
(150, 19.9, './images/cssAnimation.png', 'CSS animations', 'CSS'),
(151, 19.9, './images/cssMesures.png', 'mesures and unites of CSS', 'CSS'),
(152, 59.9, './images/javascriptEvents.png', 'javascript events', 'JS'),
(153, 15.9, './images/phpBasics.png', 'getting started with php', 'php'),
(154, 29.9, './images/cssColors.png', 'css colors', 'css'),
(155, 19.9, './images/javascriptFunctions2.png', 'functions and loops with javascript', 'JS'),
(156, 29.9, './images/phpDataBase.png', 'connecting to database using PHP', 'PHP'),
(157, 45.9, './images/phpCRUD.png', 'manipulating crud using php', 'php'),
(158, 23.9, './images/javascriptDOM.png', 'DOM the power of javascript', 'JS');

-- --------------------------------------------------------

--
-- Structure de la table `userclient`
--

CREATE TABLE `userclient` (
  `userId` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `passwordC` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `userclient`
--

INSERT INTO `userclient` (`userId`, `name`, `email`, `passwordC`) VALUES
(1, 'yaskadk', 'hamza@gmai', '12345678'),
(2, 'dzqjdzq', 'hamzadzqk@djqz', '14567890'),
(3, 'allomama', 'hamza.jojo@gmail.com', '100319709'),
(4, 'coucouc', 'dlqzq@dqzk', '100319709'),
(5, 'dzqdzdzdzd', 'dzqdqzqd@zqkdz', '10031647'),
(6, 'jdzqjdz', 'dlqdz@dzqkdzq', '123456789'),
(7, 'dqddzddz', 'dqdzq@dqdzq', '12345678'),
(8, 'dqdzzzddz', 'dzqdz@dqzdz', '200020200'),
(9, 'ouabiba', 'hamza.ouabiba@gmail.com', '100319709'),
(10, 'ouabiba', 'hamza.ouabiba@gmail.com', '100319709'),
(11, 'ouabiba', '100319709@feskfs', '100319709'),
(12, 'imadehamza', 'hamza.ouabiba@gmail.com', '100319709'),
(13, 'dzqdqzzqdzq', 'dqzdzqdzqd@qdkzq', '100319709'),
(14, 'hamzaOn', 'hamza.ouabiba@gmail.com', '100319709'),
(15, 'dzqddzq', 'dlzqdlzq@dzqldzq', '100319709'),
(16, 'dzlqdzqldlz', 'DZQKZQ@fsefe', '100319709'),
(17, 'hamzaon', 'hamza.ouabiba@gmai', '100319709'),
(18, 'dzzqzdqdd', 'Dzqkd@dqzdzq', '100319709'),
(19, 'OUABIBA', 'hamza.ouabiba@gmail.com', '100319709');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`idCmd`),
  ADD KEY `iduser` (`userid`);

--
-- Index pour la table `contient`
--
ALTER TABLE `contient`
  ADD KEY `idCmd` (`idCmd`),
  ADD KEY `idCourse` (`idCourse`);

--
-- Index pour la table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`courseId`);

--
-- Index pour la table `userclient`
--
ALTER TABLE `userclient`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `idCmd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT pour la table `course`
--
ALTER TABLE `course`
  MODIFY `courseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT pour la table `userclient`
--
ALTER TABLE `userclient`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `userclient` (`userId`);

--
-- Contraintes pour la table `contient`
--
ALTER TABLE `contient`
  ADD CONSTRAINT `contient_ibfk_1` FOREIGN KEY (`idCmd`) REFERENCES `commande` (`idCmd`),
  ADD CONSTRAINT `contient_ibfk_2` FOREIGN KEY (`idCourse`) REFERENCES `course` (`courseId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
